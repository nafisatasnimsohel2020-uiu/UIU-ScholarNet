<?php

// STEP 1: INITIALIZATION & SECURITY

require_once('../includes/auth_check.php');
require_once('../includes/csrf.php');

// STEP 2: DEFINE STATIC CHANNELS
// ==========================================
$channels_map = [];

// Fetch projects user is involved in
$pRes = db_query("
    SELECT p.id, p.title, p.description 
    FROM projects p
    LEFT JOIN project_members pm ON p.id = pm.project_id AND pm.user_id = ?
    WHERE p.creator_id = ? OR pm.user_id = ?
", [$user_id, $user_id, $user_id], "iii");
while ($p = $pRes->fetch_assoc()) {
    $c_name = 'project_' . $p['id'];
    $channels_map[$c_name] = [
        'name' => htmlspecialchars($p['title']),
        'badge' => strtoupper(substr($p['title'], 0, 2)),
        'color' => 'bg-orange',
        'desc' => htmlspecialchars(substr($p['description'] ?? 'Project Channel', 0, 30) . '...')
    ];
}

// Add custom dynamic channels from database
$custom_channels_res = db_query("SELECT DISTINCT channel FROM messages WHERE channel NOT IN ('general') AND channel NOT LIKE 'project_%'");
if ($custom_channels_res) {
    while ($row = mysqli_fetch_assoc($custom_channels_res)) {
        $c_name = $row['channel'];
        $channels_map[$c_name] = [
            'name' => ucwords(str_replace('_', ' ', $c_name)),
            'badge' => strtoupper(substr($c_name, 0, 2)),
            'color' => 'bg-blue',
            'desc' => 'Custom user-created channel.'
        ];
    }
}

// STEP 3: ROUTING & FETCHING MESSAGES

$chat_user_id = isset($_GET['user_id']) ? (int)$_GET['user_id'] : 0;
$channel = '';
$chat_target_info = [];
$messages = null;

// Case A: Direct Messaging (DM)
if ($chat_user_id > 0) {
    $chat_user_data = db_query("SELECT * FROM users WHERE id = ?", [$chat_user_id], "i")->fetch_assoc();
    
    if ($chat_user_data) {
        $is_online = false;
        if (!empty($chat_user_data['last_active_at'])) {
            if (time() - strtotime($chat_user_data['last_active_at']) <= 300) {
                $is_online = true;
            }
        }
        $status_text = $is_online ? '<span style="color: #10b981; font-weight: 600;">Online</span>' : '<span style="color: #6b7280;">Offline</span>';

        $chat_target_info = [
            'name' => htmlspecialchars($chat_user_data['full_name']),
            'badge' => strtoupper(substr($chat_user_data['full_name'], 0, 2)),
            'color' => 'bg-orange',
            'desc' => $status_text . ' • ' . ucfirst(htmlspecialchars($chat_user_data['role']))
        ];
        
        // Mark as read
        $upd = $conn->prepare("UPDATE messages SET is_read = 1 WHERE sender_id = ? AND receiver_id = ? AND is_read = 0");
        $upd->bind_param("ii", $chat_user_id, $user_id);
        $upd->execute();
        
        $messages = db_query("
            SELECT m.*, u.full_name
            FROM messages m
            JOIN users u ON u.id = m.sender_id
            WHERE (m.sender_id = ? AND m.receiver_id = ?) OR (m.sender_id = ? AND m.receiver_id = ?)
            ORDER BY m.created_at ASC LIMIT 100
        ", [$user_id, $chat_user_id, $chat_user_id, $user_id], "iiii");
    } else {
        $chat_user_id = 0; // Fallback to channel
    }
}

// Case B: Channel Chat
if ($chat_user_id === 0) {
    $channel = isset($_GET['channel']) ? (string)$_GET['channel'] : '';
    
    // If no channel is specified or invalid, default to the first available channel in the map
    if (empty($channel) || !preg_match('/^[a-z0-9_-]{1,50}$/', $channel) || !isset($channels_map[$channel])) {
        reset($channels_map);
        $channel = key($channels_map);
    }
    
    if ($channel) {
        $chat_target_info = $channels_map[$channel] ?? [
            'name' => ucwords(str_replace('_', ' ', $channel)),
            'badge' => strtoupper(substr($channel, 0, 2)),
            'color' => 'bg-blue',
            'desc' => 'Custom channel.'
        ];
        
        if (strpos($channel, 'project_') === 0) {
            $proj_id = (int)str_replace('project_', '', $channel);
            $online_res = db_query("
                SELECT COUNT(DISTINCT pm.user_id) as cnt 
                FROM project_members pm
                JOIN users u ON u.id = pm.user_id
                WHERE pm.project_id = ? AND u.last_active_at > (NOW() - INTERVAL 5 MINUTE)
            ", [$proj_id], "i")->fetch_assoc();
            $online_cnt = $online_res['cnt'] ?? 0;
            $chat_target_info['desc'] = '<span style="color: #10b981; font-weight: 600;">' . $online_cnt . ' Members Online</span> • ' . $chat_target_info['desc'];
        }
        
        $messages = db_query("
            SELECT m.*, u.full_name
            FROM messages m
            JOIN users u ON u.id = m.sender_id
            WHERE m.channel = ? AND m.receiver_id IS NULL
            ORDER BY m.created_at ASC LIMIT 100
        ", [$channel], "s");
    } else {
        $chat_target_info = [
            'name' => 'No Team Channels',
            'badge' => '--',
            'color' => 'bg-blue',
            'desc' => 'Create or join a project to unlock team messaging.'
        ];
        $messages = null;
    }
}

// Fetch users for the sidebar (Connections from projects OR users you've DM'd)
$dm_users_res = db_query("
    SELECT DISTINCT u.id, u.full_name, u.role, u.last_active_at,
           (SELECT COUNT(*) FROM messages m_un WHERE m_un.sender_id = u.id AND m_un.receiver_id = ? AND m_un.is_read = 0) as unread_count
    FROM users u
    WHERE u.id != ? 
    AND (
        EXISTS (
            SELECT 1 FROM project_members pm1
            JOIN project_members pm2 ON pm1.project_id = pm2.project_id
            WHERE pm1.user_id = u.id AND pm2.user_id = ?
        )
        OR
        EXISTS (
            SELECT 1 FROM messages m
            WHERE (m.sender_id = ? AND m.receiver_id = u.id) 
               OR (m.sender_id = u.id AND m.receiver_id = ?)
        )
    )
    ORDER BY unread_count DESC, u.full_name ASC
    LIMIT 50
", [$user_id, $user_id, $user_id, $user_id, $user_id], "iiiii");

// STEP 4: PRESENTATION (HTML UI)

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Messages | UIU ScholarNet</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Playfair+Display:ital,wght@0,700;1,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/messages.css">
</head>
<body class="dashboard-page messages-full-page">

    <?php include('../includes/sidebar.php'); ?>

    <main class="main-content pt-1">
        
        <div class="messages-layout">
            
            <!-- LEFT COLUMN: Navigation -->
            <aside class="comm-sidebar">
                <div class="comm-sidebar-header">
                    <h2>Messages</h2>
                </div>
                
                <div class="comm-sidebar-list">
                    <h4>TEAM CHANNELS</h4>
                    <?php foreach ($channels_map as $key => $info): ?>
                        <a href="?channel=<?php echo urlencode($key); ?>" class="channel-item <?php echo ($channel === $key) ? 'active' : ''; ?>">
                            <div class="avatar-badge <?php echo htmlspecialchars($info['color']); ?>"><?php echo htmlspecialchars($info['badge']); ?></div>
                            <div class="item-info">
                                <div class="item-name"># <?php echo htmlspecialchars($info['name']); ?></div>
                                <div class="item-preview"><?php echo htmlspecialchars($info['desc']); ?></div>
                            </div>
                        </a>
                    <?php endforeach; ?>

                    <h4>DIRECT MESSAGES</h4>
                    <div class="user-search-container">
                        <input type="text" id="userSearchInput" class="user-search-input" placeholder="Search users to DM..." autocomplete="off">
                        <div id="userSearchResults" class="user-search-results d-none"></div>
                    </div>
                    <?php if ($dm_users_res && $dm_users_res->num_rows > 0): ?>
                        <?php while ($dm_user = $dm_users_res->fetch_assoc()): ?>
                            <a href="?user_id=<?php echo $dm_user['id']; ?>" class="dm-item <?php echo ($chat_user_id === (int)$dm_user['id']) ? 'active' : ''; ?>">
                                <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($dm_user['full_name']); ?>&background=<?php echo ($chat_user_id === (int)$dm_user['id']) ? '0a1128' : 'f8f7f2'; ?>&color=<?php echo ($chat_user_id === (int)$dm_user['id']) ? 'fff' : '0a1128'; ?>" class="avatar-badge">
                                <div class="item-info flex-between-w100">
                                    <div>
                                        <div class="item-name">
                                            <?php echo htmlspecialchars($dm_user['full_name']); ?>
                                            <?php 
                                            if (!empty($dm_user['last_active_at']) && time() - strtotime($dm_user['last_active_at']) <= 300) {
                                                echo '<span style="display:inline-block; width:8px; height:8px; background-color:#10b981; border-radius:50%; margin-left:4px;" title="Online"></span>';
                                            }
                                            ?>
                                        </div>
                                        <div class="item-preview"><?php echo htmlspecialchars($dm_user['role']); ?></div>
                                    </div>
                                    <?php if ($dm_user['unread_count'] > 0): ?>
                                        <span class="notification-dot notification-dot-inline"></span>
                                    <?php endif; ?>
                                </div>
                            </a>
                        <?php endwhile; ?>
                    <?php endif; ?>
                </div>
            </aside>

            <!-- MIDDLE COLUMN: Chat Area -->
            <div class="chat-area">
                <div class="chat-header">
                    <div class="avatar-badge <?php echo htmlspecialchars($chat_target_info['color'] ?? 'bg-blue'); ?>"><?php echo htmlspecialchars($chat_target_info['badge']); ?></div>
                    <div class="chat-title-group">
                        <div class="chat-title"><?php echo htmlspecialchars($chat_target_info['name']); ?></div>
                        <div class="chat-subtitle"><?php echo $chat_target_info['desc']; ?></div>
                    </div>
                    <div class="chat-actions pos-relative" id="chatActionsMenu">
                        <i class="fa-solid fa-ellipsis-vertical" onclick="document.getElementById('chatDropdown').classList.toggle('show')"></i>
                        <div class="dropdown-menu" id="chatDropdown">
                            <form action="../actions/clear_chat.php" method="POST" onsubmit="return confirm('Clear this chat history?');">
                                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8'); ?>">
                                <?php if ($chat_user_id > 0): ?>
                                    <input type="hidden" name="user_id" value="<?php echo $chat_user_id; ?>">
                                <?php else: ?>
                                    <input type="hidden" name="channel" value="<?php echo htmlspecialchars($channel, ENT_QUOTES, 'UTF-8'); ?>">
                                <?php endif; ?>
                                <button type="submit" class="dropdown-item btn-dropdown-clean">
                                    <i class="fa-solid fa-trash"></i> Clear Chat
                                </button>
                            </form>
                        </div>
                    </div>
                </div>

                <?php 
                ob_start();
                include('../includes/alerts.php');
                $alerts = ob_get_clean();
                if (trim($alerts)) {
                    echo '<div style="padding: 1rem 2rem 0 2rem;">' . $alerts . '</div>';
                }
                ?>

                <div class="chat-messages" id="chatContainer">
                    <?php if ($messages && $messages->num_rows > 0): ?>
                        <?php while($msg = $messages->fetch_assoc()): 
                            $is_self = ((int)$msg['sender_id'] === (int)$user_id);
                            $sender_name = $is_self ? 'You' : $msg['full_name'];
                        ?>
                            <div class="msg-bubble <?php echo $is_self ? 'self' : ''; ?>" data-msg-id="<?php echo $msg['id']; ?>">
                                <?php if (!$is_self): ?>
                                    <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($sender_name); ?>&background=ffffff&color=764ba2">
                                <?php endif; ?>
                                <div class="msg-content">
                                    <div class="msg-text">
                                        <?php echo nl2br(htmlspecialchars((string)$msg['message'])); ?>
                                        <?php if (!empty($msg['file_path'])): ?>
                                            <?php 
                                                $ext = strtolower(pathinfo($msg['file_name'], PATHINFO_EXTENSION));
                                                $img_exts = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
                                                if (in_array($ext, $img_exts)):
                                            ?>
                                                <div class="chat-image-wrapper">
                                                    <a href="../<?php echo htmlspecialchars($msg['file_path']); ?>" target="_blank">
                                                        <img src="../<?php echo htmlspecialchars($msg['file_path']); ?>" alt="Attachment" class="chat-image-attachment">
                                                    </a>
                                                </div>
                                            <?php else: ?>
                                                <a href="../<?php echo htmlspecialchars($msg['file_path']); ?>" target="_blank" class="file-attachment">
                                                    <i class="fa-solid fa-paperclip file-icon"></i>
                                                    <span class="file-name-sm-break"><?php echo htmlspecialchars($msg['file_name']); ?></span>
                                                </a>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </div>
                                    <div class="msg-meta msg-meta-flex <?php echo $is_self ? 'justify-end' : 'justify-start'; ?>">
                                        <?php if ($is_self): ?>
                                            <div class="msg-actions" onclick="deleteMessage(<?php echo $msg['id']; ?>, this)">
                                                <i class="fa-solid fa-trash"></i>
                                            </div>
                                        <?php endif; ?>
                                        <span><?php echo htmlspecialchars($sender_name); ?> • <?php echo date('g:i A', strtotime($msg['created_at'])); ?></span>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <?php if ($chat_target_info['name'] === 'No Team Channels'): ?>
                            <div class="empty-messages">
                                ✨ You don't have any active channels yet. Join a project to start collaborating! ✨
                            </div>
                        <?php else: ?>
                            <div class="empty-messages">
                                ✨ Start a beautiful conversation! ✨
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>

                <?php if ($chat_user_id > 0 || $channel): ?>
                <div class="chat-input-wrapper">
                    <form class="chat-form" action="../actions/post_message.php" method="POST" id="chatForm" enctype="multipart/form-data">
                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8'); ?>">
                        
                        <?php if ($chat_user_id > 0): ?>
                            <input type="hidden" name="receiver_id" value="<?php echo $chat_user_id; ?>">
                        <?php else: ?>
                            <input type="hidden" name="channel" value="<?php echo htmlspecialchars($channel, ENT_QUOTES, 'UTF-8'); ?>">
                        <?php endif; ?>
                        
                        <label for="chatFileInput" class="icon-btn mb-0" title="Attach file">
                            <i class="fa-solid fa-paperclip"></i>
                        </label>
                        <input type="file" name="chat_file" id="chatFileInput" class="d-none" onchange="updateFileLabel(this)">
                        
                        <input name="message" type="text" class="chat-input" id="chatTextInput" placeholder="Type your message..." autocomplete="off">
                        
                        <button type="submit" class="send-btn">
                            <i class="fa-solid fa-paper-plane"></i>
                        </button>
                    </form>
                    <div id="fileAttachmentPreview" class="file-preview-inline" style="display: none; margin-top: 0.5rem; font-size: 0.8rem; color: var(--primary-color); font-weight: 500;">
                        <i class="fa-solid fa-paperclip"></i> <span id="fileNameDisplay"></span>
                    </div>
                </div>
                <?php endif; ?>
            </div>

            <!-- RIGHT COLUMN: Context Info Pane -->
            <aside class="info-sidebar">
                <div class="avatar-badge info-badge-lg <?php echo htmlspecialchars($chat_target_info['color'] ?? 'bg-blue'); ?>">
                    <?php echo htmlspecialchars($chat_target_info['badge']); ?>
                </div>
                <h3 class="info-title"><?php echo htmlspecialchars($chat_target_info['name']); ?></h3>
                <p class="info-desc"><?php echo $chat_target_info['desc']; ?></p>

                <h4 class="info-section-title">Shared Media</h4>
                <div class="media-grid">
                    <?php 
                    $mediaRes = db_query("SELECT id, title, file_path, created_at FROM resources WHERE user_id = ? ORDER BY created_at DESC LIMIT 3", [$user_id], "i");
                    if ($mediaRes->num_rows > 0):
                        while ($m = $mediaRes->fetch_assoc()):
                    ?>
                        <div class="media-item media-item-bg" title="<?php echo htmlspecialchars($m['title']); ?>" style="background-image: url('../<?php echo htmlspecialchars($m['file_path']); ?>');"></div>
                    <?php endwhile; else: ?>
                        <div class="empty-text-span3">No media uploaded.</div>
                    <?php endif; ?>
                </div>

                <h4 class="info-section-title">Pinned Artifacts</h4>
                <?php 
                $docRes = db_query("
                    SELECT d.id, d.title, d.created_at, p.title as project_title 
                    FROM documents d
                    JOIN projects p ON d.project_id = p.id
                    LEFT JOIN project_members pm ON p.id = pm.project_id AND pm.user_id = ?
                    WHERE p.creator_id = ? OR pm.user_id = ?
                    ORDER BY d.created_at DESC LIMIT 2
                ", [$user_id, $user_id, $user_id], "iii");
                if ($docRes->num_rows > 0):
                    while ($d = $docRes->fetch_assoc()):
                ?>
                <div class="pinned-card">
                    <i class="fa-solid fa-file-lines icon-lg-primary"></i>
                    <div>
                        <div class="pinned-title-sm"><?php echo htmlspecialchars($d['title']); ?></div>
                        <div class="pinned-meta-xs">In <?php echo htmlspecialchars($d['project_title']); ?></div>
                    </div>
                </div>
                <?php endwhile; else: ?>
                    <div class="empty-text-center">No pinned artifacts found.</div>
                <?php endif; ?>
            </aside>
        </div>
        <!-- JavaScript logic for AJAX messaging (simulated realtime) -->
    <script>
        const chatContainer = document.getElementById('chatContainer');
        if (chatContainer) chatContainer.scrollTop = chatContainer.scrollHeight;

        const chatForm = document.getElementById('chatForm');
        let currentUserId = <?php echo (int)$user_id; ?>;
        let chatTargetUserId = <?php echo (int)$chat_user_id; ?>;
        let currentChannel = "<?php echo addslashes($channel); ?>";

        if (chatForm) {
            chatForm.addEventListener('submit', function(e) {
                e.preventDefault();
                const formData = new FormData(chatForm);
                const inputField = chatForm.querySelector('.chat-input');
                const text = inputField.value.trim();
                if (text === '') return;
                
                const emptyMsg = chatContainer.querySelector('.empty-messages');
                if (emptyMsg) emptyMsg.remove();
                
                const bubble = document.createElement('div');
                bubble.className = 'msg-bubble self temp-bubble';
                bubble.innerHTML = `
                    <div class="msg-content">
                        <div class="msg-text opacity-80">${text.replace(/</g, "&lt;").replace(/>/g, "&gt;")}</div>
                        <div class="msg-meta">You • Sending...</div>
                    </div>
                `;
                chatContainer.appendChild(bubble);
                chatContainer.scrollTop = chatContainer.scrollHeight;
                inputField.value = '';
                
                fetch(chatForm.action, {
                    method: 'POST',
                    body: formData,
                    headers: { 'X-Requested-With': 'XMLHttpRequest' }
                })
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        bubble.querySelector('.msg-text').style.opacity = '1';
                        bubble.querySelector('.msg-meta').innerText = 'You • Just now';
                        bubble.classList.remove('temp-bubble');
                        if (data.message_id) {
                            bubble.setAttribute('data-msg-id', data.message_id);
                        }
                        pollMessages(); // Immediately poll after sending
                    }
                });
            });
        }
        // Live Chat Polling
        function pollMessages() {
            if (!chatContainer) return;
            const bubbles = chatContainer.querySelectorAll('.msg-bubble:not(.temp-bubble)');
            let lastId = 0;
            if (bubbles.length > 0) {
                const lastBubble = bubbles[bubbles.length - 1];
                if (lastBubble.hasAttribute('data-msg-id')) {
                    lastId = parseInt(lastBubble.getAttribute('data-msg-id'), 10);
                }
            }
            
            let url = '../actions/fetch_messages.php?last_id=' + lastId;
            if (chatTargetUserId > 0) {
                url += '&user_id=' + chatTargetUserId;
            } else if (currentChannel) {
                url += '&channel=' + encodeURIComponent(currentChannel);
            } else {
                return;
            }

            fetch(url)
                .then(r => r.json())
                .then(data => {
                    if (data.success && data.messages.length > 0) {
                        const emptyMsg = chatContainer.querySelector('.empty-messages');
                        if (emptyMsg) emptyMsg.remove();
                        
                        let needsScroll = false;
                        if (chatContainer.scrollHeight - chatContainer.scrollTop - chatContainer.clientHeight < 50) {
                            needsScroll = true;
                        }

                        data.messages.forEach(msg => {
                            if (chatContainer.querySelector(`.msg-bubble[data-msg-id="${msg.id}"]`)) return;

                            const isSelf = parseInt(msg.sender_id) === currentUserId;
                            const senderName = isSelf ? 'You' : msg.full_name;
                            const bubble = document.createElement('div');
                            bubble.className = 'msg-bubble ' + (isSelf ? 'self' : '');
                            bubble.setAttribute('data-msg-id', msg.id);
                            
                            let html = '';
                            if (!isSelf) {
                                html += `<img src="https://ui-avatars.com/api/?name=${encodeURIComponent(senderName)}&background=ffffff&color=764ba2">`;
                            }
                            
                            const date = new Date(msg.created_at);
                            const timeStr = date.toLocaleTimeString([], {hour: 'numeric', minute:'2-digit'});

                            let attachmentHtml = '';
                            if (msg.file_path && msg.file_name) {
                                const ext = msg.file_name.split('.').pop().toLowerCase();
                                const imgExts = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
                                if (imgExts.includes(ext)) {
                                    attachmentHtml = `
                                    <div class="chat-image-wrapper">
                                        <a href="../${msg.file_path}" target="_blank">
                                            <img src="../${msg.file_path}" alt="Attachment" class="chat-image-attachment">
                                        </a>
                                    </div>`;
                                } else {
                                    attachmentHtml = `
                                    <a href="../${msg.file_path}" target="_blank" class="file-attachment">
                                        <i class="fa-solid fa-paperclip file-icon"></i>
                                        <span class="file-name-sm-break">${msg.file_name}</span>
                                    </a>`;
                                }
                            }

                            html += `
                                <div class="msg-content">
                                    <div class="msg-text">${msg.message.replace(/</g, "&lt;").replace(/>/g, "&gt;")} ${attachmentHtml}</div>
                                    <div class="msg-meta msg-meta-flex ${isSelf ? 'justify-end' : 'justify-start'}">
                                        ${isSelf ? `<div class="msg-actions" onclick="deleteMessage(${msg.id}, this)"><i class="fa-solid fa-trash"></i></div>` : ''}
                                        <span>${senderName} • ${timeStr}</span>
                                    </div>
                                </div>
                            `;
                            bubble.innerHTML = html;
                            chatContainer.appendChild(bubble);
                        });

                        const tempBubbles = chatContainer.querySelectorAll('.temp-bubble');
                        tempBubbles.forEach(tb => tb.remove());

                        if (needsScroll) {
                            chatContainer.scrollTop = chatContainer.scrollHeight;
                        }
                    }
                })
                .catch(err => console.error(err));
        }

        // Poll every 3 seconds
        setInterval(pollMessages, 3000);

        // Click outside dropdown to close
        document.addEventListener('click', function(e) {
            const menu = document.getElementById('chatDropdown');
            if (menu && menu.classList.contains('show') && !e.target.closest('#chatActionsMenu')) {
                menu.classList.remove('show');
            }
        });

        function updateFileLabel(input) {
            const display = document.getElementById('fileAttachmentPreview');
            const nameSpan = document.getElementById('fileNameDisplay');
            const textInput = document.getElementById('chatTextInput');
            if (input.files.length > 0) {
                nameSpan.textContent = input.files[0].name;
                display.style.display = 'block';
                textInput.removeAttribute('required'); // message text not required if file is attached
            } else {
                display.style.display = 'none';
                textInput.setAttribute('required', 'true');
            }
        }

        function deleteMessage(msgId, el) {
            if (!confirm('Delete this message?')) return;
            const formData = new FormData();
            formData.append('csrf_token', '<?php echo htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8'); ?>');
            formData.append('message_id', msgId);

            fetch('../actions/delete_message.php', {
                method: 'POST',
                body: formData
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    el.closest('.msg-bubble').remove();
                } else {
                    alert('Failed to delete message: ' + (data.message || 'Unknown error'));
                }
            });
        }

        // Intercept form submit to handle files properly in JS if needed
        // The existing JS fetch already handles FormData which includes files!
        if (chatForm) {
            const oldSubmit = chatForm.onsubmit;
            chatForm.addEventListener('submit', function(e) {
                // If the old JS is catching it, let's just make sure it clears the file input
                setTimeout(() => {
                    document.getElementById('chatFileInput').value = '';
                    updateFileLabel(document.getElementById('chatFileInput'));
                }, 100);
            });
        }

        const userSearchInput = document.getElementById('userSearchInput');
        const userSearchResults = document.getElementById('userSearchResults');
        let searchTimeout = null;

        if (userSearchInput) {
            userSearchInput.addEventListener('input', function() {
                const q = this.value.trim();
                clearTimeout(searchTimeout);
                
                if (q.length < 2) {
                    userSearchResults.classList.add('d-none');
                    return;
                }
                
                searchTimeout = setTimeout(() => {
                    fetch('../actions/search_users.php?q=' + encodeURIComponent(q))
                        .then(r => r.json())
                        .then(data => {
                            if (data.success && data.users.length > 0) {
                                let html = '';
                                data.users.forEach(u => {
                                    const encodedName = encodeURIComponent(u.name);
                                    html += `
                                    <a href="?user_id=${u.id}" class="search-result-item">
                                        <img src="https://ui-avatars.com/api/?name=${encodedName}&background=f8f7f2&color=0a1128" class="avatar-badge-sm">
                                        <div>
                                            <div class="item-name">${u.name}</div>
                                            <div class="item-preview">${u.role}</div>
                                        </div>
                                    </a>`;
                                });
                                userSearchResults.innerHTML = html;
                                userSearchResults.classList.remove('d-none');
                            } else {
                                userSearchResults.innerHTML = '<div class="search-result-empty">No users found</div>';
                                userSearchResults.classList.remove('d-none');
                            }
                        });
                }, 300);
            });

            // Close search results when clicking outside
            document.addEventListener('click', function(e) {
                if (userSearchResults && !e.target.closest('.user-search-container')) {
                    userSearchResults.classList.add('d-none');
                }
            });
        }
    </script>
</body>
</html>
