<?php
// actions/restore_version.php - Compatibility wrapper
include __DIR__ . '/project_task_document/restore_version.php';
