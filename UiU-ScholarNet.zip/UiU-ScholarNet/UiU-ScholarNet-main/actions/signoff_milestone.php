<?php
// actions/signoff_milestone.php - Compatibility wrapper
include __DIR__ . '/project_task_document/signoff_milestone.php';
