<?php
// actions/update_research_phase.php - Compatibility wrapper
include __DIR__ . '/project_task_document/update_research_phase.php';
